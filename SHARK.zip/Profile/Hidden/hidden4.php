<!DOCTYPE html>
<html>

<body>

    <h1>Hidden Message</h1>
    <h2 style="color: #696969;"> Profile 4</h2>
    <h3> <span class="rainbow-text">Congratulations!</span> - You have done the file inclusion mission</h3></br>
    <img src="../Image/coconut_star.png" width="500" height="450">
    <h3>Deep inside, I dream of becoming the first coconut K-pop superstar, rocking stages with my tropical charm!</h3>
</body>

</html>