<!DOCTYPE html>
<html>

<body>

    <h1>Hidden Message</h1>
    <h2 style="color: #696969;"> Profile 3</h2>
    <h3> <span class="rainbow-text">Congratulations!</span> - You have done the file inclusion mission</h3></br>
    <img src="../Image/spongebob_comedy.png" width="500" height="450">
    <h3>When I'm not flipping Krabby Patties, I secretly host underwater stand-up comedy nights!</h3>
</body>

</html>