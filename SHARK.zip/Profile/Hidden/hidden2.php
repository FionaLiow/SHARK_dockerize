<!DOCTYPE html>
<html>


<body>

    <h1>Hidden Message</h1>
    <h2 style="color: #696969;"> Profile 2</h2>
    <h3> <span class="rainbow-text">Congratulations!</span> - You have done the file inclusion mission</h3></br>
    <img src="../Image/nemo_restaurant.png" width="500" height="350">
    <h3>When I'm not exploring, I love collecting Happy Meal toys from that place with the clown mascot!</h3>
</body>

</html>