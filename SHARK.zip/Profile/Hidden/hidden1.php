<!DOCTYPE html>
<html>

<body>

    <h1>Hidden Message</h1>
    <h2 style="color: #696969;"> Profile 1</h2>
    <h3> <span class="rainbow-text">Congratulations!</span> - You have done the file inclusion mission</h3></br>
    <img src="../Image/cozy_shark.png" width="500" height="450">
    <h3>When I'm not hunting, you'll find me knitting cozy blankets for my ocean friends.</h3>
</body>

</html>