<!DOCTYPE html>
<html>

<body>
    <h1>Profile Picture</h1>
    <h2 style="color: #6082B6;">Profile 3</h2></br>
    <img src="../Image/spongebob.png" width="500" height="350">
</body>

</html>