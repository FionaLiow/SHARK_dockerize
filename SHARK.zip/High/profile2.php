<!DOCTYPE html>
<html>

<body>
    <h1>Profile Picture</h1>
    <h2 style="color: #6082B6;">Profile 2</h2></br>
    <img src="../Image/nemo.jpg" width="500" height="300">
</body>

</html>