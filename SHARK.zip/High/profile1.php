<!DOCTYPE html>
<html>

<body>
    <h1>Profile Picture</h1>
    <h2 style="color: #6082B6;">Profile 1</h2>
    <img src="../Image/shark-welcome.jpg">
</body>

</html>