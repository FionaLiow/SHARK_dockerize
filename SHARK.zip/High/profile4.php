<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="../Style/home.css">
</head>

<body>
    </br>
    <h1>Profile Picture</h1>
    <p>You have found a <span class="emphasize">hidden page</span> which is not listed in the profile links.</p>
    <p><span style="font-weight:bold;">You have followed a right path, continue to complete your final mission.</span></p></br>
    <img src="../Image/coconut.png" width="500" height="400">
</body>

</html>