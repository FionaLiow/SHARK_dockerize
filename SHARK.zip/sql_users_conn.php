<?php
$host = 'db';  // Docker Compose service name
$db = 'shark';
$user = 'root';
$pass = 'my_secure_password';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected to MySQL database successfully!";
?>
